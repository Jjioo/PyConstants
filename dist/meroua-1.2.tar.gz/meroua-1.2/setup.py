import setuptools

setuptools.setup(
    name='meroua',
    version='1.2',
    description='A module that defines a constant type in Python using Jython',
    author='Sahraoui Tarek Ziad',
    author_email='tziad2027@gmail.com',
    packages=setuptools.find_packages(),
    py_modules=['meroua.mymod'],
)
