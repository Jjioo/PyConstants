from .mymod import meroua
c_ = meroua()
